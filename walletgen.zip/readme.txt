Open a terminal and type the following commands to launch WalletGen.

1. cd path/to/walletgen
2. chmod +x run.sh
3. ./walletgen.sh


